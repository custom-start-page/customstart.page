# Windows 95 Inspired Start Page

A simple start page designed to emulate the look and feel of Windows 95.

## Features

### Folder and links

You can define the folders and the links in each folder in the start menu.
